
public class Customer {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void setName(String aName) {
        name = aName;
    }

    public void setAge(int aAge) {
        age = aAge;
    }
}








