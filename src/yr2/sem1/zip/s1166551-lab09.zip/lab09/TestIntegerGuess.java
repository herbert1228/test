public class TestIntegerGuess {
    public static void main(String args[]){
        IntegerGuess guess = new IntegerGuess();
        //guess.setSecretInteger(5);
        //System.out.println(guess.getSecretInteger());
        guess.play();
    }
}
