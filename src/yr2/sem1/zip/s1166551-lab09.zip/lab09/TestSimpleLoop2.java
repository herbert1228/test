public class TestSimpleLoop2 {
    public static void main(String args[]){
        SimpleLoop2 test = new SimpleLoop2();
        test.upCounter(8);
        test.printStars(5);
        test.printStars(0);
        test.printHistogram(3, 5, 2);

    }
}
