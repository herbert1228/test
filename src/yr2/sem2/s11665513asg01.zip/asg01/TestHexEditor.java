package yr2.sem2.asg01;

public class TestHexEditor {
    public static void main(String[] args) {
        HexEditor anEditor = new HexEditor();
        anEditor.setVisible(true);
    }
}
